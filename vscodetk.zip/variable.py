a = 123
b = "tarun"
c = 2.2
print(type(a)) # class int
print(type(b)) # class str
print(type(c)) # class float

d = None
d = True
s11 =6 
print(s11)

a = 33
A = 87
print(a)
print(A)










