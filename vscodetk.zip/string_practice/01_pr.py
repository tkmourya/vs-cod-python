name = input("enter your name\n")
print("good atfernoon, "+name)  