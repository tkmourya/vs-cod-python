letter = "Dear Tarun,This python course is nice! Thanks!"
print(letter)

formetted_letter = "Dear Tarun,\n\tThis python course is nice!\nThanks!"
print(formetted_letter)