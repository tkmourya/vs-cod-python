a = input("enter first number")
b = input("enter second number")
a = int(a)
b = int(b)
avg = (a+b)/2
print("the averge of a and b is",avg)
