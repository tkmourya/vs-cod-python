story = "once upon a time there was a channel named tk entertaniment who uploaded video with tital"


# string functions
print(len(story))               # 89
print(story.endswith("tital"))  # true
print(story.count("t"))         # 9
print(story.capitalize())       # once upon a time there was a channel named tk entertaniment who uploaded video with tital      # 
print(story.find("a"))          # 10
print(story)

