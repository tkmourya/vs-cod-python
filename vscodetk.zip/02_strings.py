a = 55
b = "tarun"
c = "tarun's"
print(a,b,c)
print(type(c))
