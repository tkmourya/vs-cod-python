class sample:
    a = "tarun"

obj = sample()
obj.a = "vikky"

print(sample.a)
print(obj.a)