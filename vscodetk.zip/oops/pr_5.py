class sample:
#    def __init__(self, name):
#     self.name = name

 def __init__(sy, name): # self change no any error
    sy.name = name

obj = sample("tarun")
print(obj.name)