a = 2
b = 3
c = 4
d = a+b-c
print("ans",d)
              
print("helloworld")
print(770)
# coding with the tarun
# and module use
import os
print(os.listdir())










              