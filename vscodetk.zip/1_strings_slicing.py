greeting = "good moring, "
name = "tarun"
#print(type(name))
print(greeting+name)
# or
c =greeting+name
print(c) # good moring, tarun
print(name[1:5]) # print carector 1 or 2 or full carector ex:[0] print out t and [2] print out r:
print(name[:5])  # is same as name[0:5]
print(name[1:])  # is same as name[1:5]
print(name[-5])  # is same as is name[0]
name = "tarunisgood"
d = name[0::3]  # skip 3 word print tuso:
print(d)
