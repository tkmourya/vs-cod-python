# can we have a set with 18(int)and"18"(str) as a value in it?

s = {18,"18",}
s = {18,"18",12, 18,18,90}
print(s)


