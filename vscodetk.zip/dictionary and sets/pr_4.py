# write will be the length of following set s:
# s = set()
# s.add(20)
# s.add(20.0)
# s.add("20")

s = {20, 20.0, 20, "20"}
print(s)
print(len(s))
h =set() #emputy set class set
h ={} # class dictionary
print(type(h))