# write a program to input eight numbers form the user and display all the unique numbers.
 
num1 = int(input("enter number 1\n"))
num2 = int(input("enter number 2\n"))
num3 = int(input("enter number 3\n"))
num4 = int(input("enter number 4\n"))
num5 = int(input("enter number 5\n"))
num6 = int(input("enter number 6\n"))
num7 = int(input("enter number 7\n"))
num8 = int(input("enter number 8\n"))

s = {num1, num2, num3, num4, num5, num6, num7, num8}
print(s)