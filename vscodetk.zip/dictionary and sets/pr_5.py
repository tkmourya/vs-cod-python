    # create an emputy dictionary allow 4 friends to enter thir favourite 
    # language as value and use keys as thir name. assume that the names are uniqe?




favlang = {}
a = input("enter your favorite language shubham\n")
b = input("enter your favorite language ankit\n")
c = input("enter your favorite language sonali\n")
d = input("enter your favorite language harshita\n")
favlang['shubham'] = a
favlang['ankit'] = b
favlang['sonsli'] =c
favlang['harshita'] =d

print(favlang)
