a = 3
b = 8

# arithmetic operators
print(a+b)
print(a-b)
print(a*b)
print(a/b)


# assignment operators
a = 5
a += 1
a -= 2
a *= 3
a /= 4
print(a)

# camparison operators
b = (4<2)
print(b)
a = (4>2)
print(a)
c = (4>=2)
print(c)
d = (2!=2)
print(d)


# logical operators
bool1 = True
bool2 = False

print("thep value of bool1 and is ",(bool1 and bool2))
print("thep value of bool1 and is ",(bool1 or bool2))
print("thep value of bool1 and is ",(not bool1))



