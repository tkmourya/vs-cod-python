a = 34
b = 6
print("the sum of a and b is",a+b)