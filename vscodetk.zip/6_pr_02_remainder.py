a = 45
b = 10

print("the remainder when a is divided by b is",a%b)