a = "656"
a = int(a)
print(a)
print(a/2)

c = 555
c = int(c)
print(c)
# convert type int to complex
a = 5
a = complex(a)  # 5+0j
print(a)
 