# listpractics
m1 =int(input("enter marks for student number 1: "))
m2 =int(input("enter marks for student number 2: "))
m3 =int(input("enter marks for student number 3: "))
m4 =int(input("enter marks for student number 4: "))
m5 =int(input("enter marks for student number 5: "))

mylist = [m1, m2, m3, m4, m5]
mylist.sort()
print(mylist)

                                                