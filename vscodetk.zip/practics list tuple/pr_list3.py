a = (4,5,6,0,0,0,5)
b = a.count(5)
print(b)