f1 = input("enter frut number 1: ")
f2 = input("enter frut number 2: ")
f3 = input("enter frut number 3: ")
f4 = input("enter frut number 4: ")
f5 = input("enter frut number 5: ")
f6 = input("enter frut number 6: ")
f7 = input("enter frut number 7: ")
f8 = input("enter frut number 8: ")
f9 = input("enter frut number 9: ")

myfruitlists = ["f1, f2, f3, f4, f5, f6, f7, f8, f9,"]
print(myfruitlists)







