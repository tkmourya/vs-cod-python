
f = open("er.txt", "r")
data = f.read()
print(data)
f.close()