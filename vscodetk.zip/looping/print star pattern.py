
n = 5
for i in range(n):
    print("*" * (i+1)) # print'*' i+1 times

n = 5
for i in range(n):
    print("*" * (n-i)) # print'*'  n-i times