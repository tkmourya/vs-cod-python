num = int(input("enter the number: "))
sum = 0
for i in range(1, num+1):
    sum = sum + i
    print(f"the sum of {num} is {sum}")