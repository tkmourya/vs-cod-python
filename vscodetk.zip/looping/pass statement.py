i = 5
if i<8:
    pass   # pass is none statement "do nothing"

def run(player):
    pass   # this statement skip throgh pass
def ooh(player):
    pass
print("tarun")