l1 = ['l','e','l','k']
for g in l1:
    print(g)

l1 = ['mango','black','white']
l2 = ['chir','book','laptop']
for i in l1:
    for j in l2:
        print(i,j)


l1 = ["tarun","sohan","rohit","rahul"]
for name in l1:
    if name.startswith("s"):
        print("hello "+ name)