i = 1
while i <= 10:
    print(i)
    i=i+1


i = 1
n = 2
while i<=10:
    print(n,'*',i,'=',n*i)
    i=i+1
 #while loop
fruits = ['banana','watermelon','grapes','mango']
i = 0
while i<len(fruits):
    print(fruits[i])
    i = i+1

#for loop
fruits = ['banana','watermelon','grapes','mango']
for item in fruits:
    print(item)


# for i in range(9):
#     print(i)

for i in range(2, 9):
    print(i)

else:
    print("done")

# another

for i in range (9):
  
    if i == 6:
        continue #and use break for stop 
    print(i)
    