a = input("enter a number:")
a = int(a)  # convert to integer(if possible)
print(type(a))

