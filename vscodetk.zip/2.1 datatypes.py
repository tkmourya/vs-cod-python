# integer datatype
print(6556)
a = 10
# FLOAT DATATYPE
print(type(a))
b = 10.9
print(type(b))
# complex datatype
c = 2+2j
print(type(c))
# set datatype
f = {'a''b''c'}
print(type(f))
# Dictionary datatype
x = {"key": "value"}
print(type(x))
# Sequence datatype

# List datatype
l1 = [1, 2, 3, 4, 5]
print(type(l1))
x = "Tarun"
y = "kumar"
z = x+y
print(z)
# integer value to the variable
a = 10
print(a)
print(type(a))
# float value of the variable
b = 10.6
print(b)
# string value of the variable
c = "python"
print(c)

# list store in variable
l1 = [1, 2, 3, 4, 5]
print(l1)
print(type(l1))
# tuple store in variable
t1 = (1, 2, 3)
print(t1)
print(type(t1))
