class Animal:
    animaltype = "mammal"

class Pets:
    color ="white"

class Dog:
    @staticmethod
    def bark():
        print("Bow Bow!")

d = Dog()
d.bark()