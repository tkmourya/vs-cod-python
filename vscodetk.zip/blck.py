#//how to get the addition in python?


xs = [1, 2, 3, 4, 5]
print(sum(xs))


15


averages = [(x + y) / 2.0 for (x, y) in zip(my_list[:-1], my_list[1:])]







