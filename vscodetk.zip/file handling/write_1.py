


f = open('another.txt', 'w')
f.write('''please write this to the file uto good
hh. kivy_configure.hasattr
dik''')
f.close()