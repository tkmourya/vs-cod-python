def print_sum(first,second=5):
    print(first + second)
print_sum(7)

def print_sum(first,second):
    print(first + second)
print_sum(7,5)
