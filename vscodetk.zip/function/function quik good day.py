def greet(name):
    print("Good day, "+ name)

def mysum(num1, num2):
    return num1 + num2

s = mysum(8, 56)

greet("tarun")
print(s)


