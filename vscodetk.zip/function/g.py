def munti_y(x,y):
    print(x*y)
munti_y(2,7)
 
def add(x):
    print(x+10)
add(9)
