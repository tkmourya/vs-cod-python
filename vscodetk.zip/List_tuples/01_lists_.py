# list slicing
friend = ["tarun","tom","ram","rohan","rock"]
print(friend[0:4])
print(friend[-3:])