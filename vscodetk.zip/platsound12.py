import playsound as ps
ps.playsound("D:\\mius\\Tu Hi Hai.mp3")