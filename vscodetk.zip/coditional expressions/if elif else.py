a = 100
b = 800
c = 900
if a>b & a>c:
    print("a is greatest")
elif b>a & b>c:
    print("b is greatest")
else:
    print("c is greatest")
