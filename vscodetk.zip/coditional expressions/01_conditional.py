a = 22
if(a>9):
    print("greater")
else:
    print("lesser")
