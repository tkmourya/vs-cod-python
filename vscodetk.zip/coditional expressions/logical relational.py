age = int(input("enter your age: "))
if(age>34 and age<56):
    print("you can work with us")
else:
    print("you cannot work with us")