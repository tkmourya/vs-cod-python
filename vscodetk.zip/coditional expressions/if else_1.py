age = int(input("enter the age"))

if age>18:
    print("yes") 
else:
    print("no")